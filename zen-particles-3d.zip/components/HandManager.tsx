import React, { useEffect, useRef, useState } from 'react';
import * as mpHands from '@mediapipe/hands';

interface Landmark {
  x: number;
  y: number;
  z: number;
}

interface Results {
  multiHandLandmarks: Landmark[][];
  image: any;
}

interface HandManagerProps {
  onUpdate: (distance: number, rotation: number, pinch: number, detected: boolean) => void;
}

export const HandManager: React.FC<HandManagerProps> = ({ onUpdate }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!videoRef.current) return;

    let animationFrameId: number;
    let hands: any = null;
    let stream: MediaStream | null = null;

    const onResults = (results: Results) => {
      setLoading(false);
      
      if (results.multiHandLandmarks && results.multiHandLandmarks.length > 0) {
        let spreadValue = 0.5;
        let rotationValue = 0;
        let pinchValue = 0;
        
        // --- MODE: TWO HANDS (Scaling & Rotation) ---
        if (results.multiHandLandmarks.length === 2) {
          const hand1 = results.multiHandLandmarks[0][0]; // Wrist
          const hand2 = results.multiHandLandmarks[1][0]; // Wrist
          
          // 1. SCALE (Distance between wrists)
          const dx = hand1.x - hand2.x;
          const dy = hand1.y - hand2.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          // Normalize: usually distance is between 0.2 (close) and 0.8 (far)
          spreadValue = Math.min(Math.max((dist - 0.2) * 2, 0), 1);

          // 2. ROTATION (Angle between wrists)
          // Calculate angle relative to horizontal. 
          // Note: Screen coords y increases downwards, so we flip dy logic if needed, but relative angle works.
          const angle = Math.atan2(hand2.y - hand1.y, hand2.x - hand1.x);
          // Map angle to a rotation factor (-1 to 1)
          // Simple steering: if hands are level, angle is 0 (or PI). 
          // We limit to +/- 45 degrees (PI/4) for control.
          rotationValue = Math.max(Math.min(angle, 1), -1);
        } 
        
        // --- MODE: ANY HAND (Pinch) ---
        // Calculate average pinch strength of all detected hands
        let totalPinch = 0;
        results.multiHandLandmarks.forEach(hand => {
          const thumb = hand[4];
          const index = hand[8];
          const pdx = thumb.x - index.x;
          const pdy = thumb.y - index.y;
          const pDist = Math.sqrt(pdx * pdx + pdy * pdy);
          // 0.02 is closed pinch, 0.2 is open. We want 0 to 1 where 1 is TIGHT PINCH (close).
          // Map distance 0.2 -> 0.0 and 0.02 -> 1.0
          const pNorm = 1 - Math.min(Math.max((pDist - 0.02) * 6, 0), 1);
          totalPinch += pNorm;
        });
        pinchValue = totalPinch / results.multiHandLandmarks.length;

        // Fallback for single hand spread control if only 1 hand
        if (results.multiHandLandmarks.length === 1) {
           // If only 1 hand, use pinch for spread instead of pinch-effect, or just keep default
           // Using pinch for "select" is requested, so we keep spread neutral or auto-breathing
           spreadValue = 0.5; 
        }

        onUpdate(spreadValue, rotationValue, pinchValue, true);
      } else {
        onUpdate(0.5, 0, 0, false); // Default idle state
      }
    };

    const initHands = async () => {
      try {
        const mp = mpHands as any;
        const HandsClass = mp.Hands || mp.default?.Hands || (window as any).Hands;

        if (!HandsClass) {
          throw new Error("Could not load MediaPipe Hands class");
        }

        hands = new HandsClass({
          locateFile: (file: string) => {
            return `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`;
          },
        });

        hands.setOptions({
          maxNumHands: 2,
          modelComplexity: 1,
          minDetectionConfidence: 0.5,
          minTrackingConfidence: 0.5,
        });

        hands.onResults(onResults);

        stream = await navigator.mediaDevices.getUserMedia({
          video: { 
            width: { ideal: 640 },
            height: { ideal: 480 },
            facingMode: 'user'
          }
        });

        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
          
          const predict = async () => {
            if (videoRef.current && hands) {
              await hands.send({ image: videoRef.current });
            }
            animationFrameId = requestAnimationFrame(predict);
          };
          predict();
        }

      } catch (e) {
        console.error("Camera/AI error:", e);
        setError("Camera access denied.");
        setLoading(false);
      }
    };

    initHands();

    return () => {
      cancelAnimationFrame(animationFrameId);
      if (hands) hands.close();
      if (stream) stream.getTracks().forEach(track => track.stop());
    };
  }, [onUpdate]);

  return (
    <div className="fixed top-4 right-4 z-50 w-48 h-36 bg-black/40 backdrop-blur-md rounded-lg overflow-hidden border border-white/10 shadow-lg transition-opacity duration-300">
      <video
        ref={videoRef}
        className="absolute inset-0 w-full h-full object-cover opacity-50 transform scale-x-[-1]"
        playsInline
        muted
        autoPlay
      />
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        {error ? (
           <span className="text-red-400 text-xs font-bold text-center p-2">{error}</span>
        ) : loading ? (
          <div className="flex flex-col items-center">
            <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mb-2"></div>
            <span className="text-white/60 text-[10px]">Loading AI...</span>
          </div>
        ) : (
          <div className="absolute bottom-1 right-2 text-[10px] text-green-400 font-mono">
            LIVE
          </div>
        )}
      </div>
    </div>
  );
};