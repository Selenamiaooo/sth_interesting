import React, { useMemo, useRef, useEffect } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Stars, Sparkles } from '@react-three/drei';
import * as THREE from 'three';
import { generateParticles, COUNT } from '../utils/shapes';
import { ShapeType } from '../types';

interface SceneProps {
  shape: ShapeType;
  color: string;
  handFactor: number; // Scale
  handRotation: number; // Steering
  pinchStrength: number; // Turbulence/Selection
  isDetected: boolean;
}

const Particles: React.FC<SceneProps> = ({ shape, color, handFactor, handRotation, pinchStrength, isDetected }) => {
  const pointsRef = useRef<THREE.Points>(null);
  
  // Generate positions and colors based on shape
  const { positions: targetPositions, colors: targetColors } = useMemo(() => 
    generateParticles(shape, color), 
  [shape, color]);
  
  const currentPositions = useMemo(() => new Float32Array(COUNT * 3), []);
  const currentColors = useMemo(() => new Float32Array(COUNT * 3), []);

  // Init positions
  useEffect(() => {
     currentPositions.set(targetPositions);
     currentColors.set(targetColors);
  }, []); // Run once on mount to fill buffers

  // Update colors when target changes
  useEffect(() => {
     if(pointsRef.current) {
        // We lerp colors in animation loop, but we need to reset/update the target source logic
     }
  }, [targetColors]);

  useFrame((state) => {
    if (!pointsRef.current) return;

    const geometry = pointsRef.current.geometry;
    const posAttr = geometry.attributes.position;
    const colAttr = geometry.attributes.color;
    
    const positions = posAttr.array as Float32Array;
    const colors = colAttr.array as Float32Array;
    
    // 1. SCALE / BREATHING
    let expansion = 1.0;
    if (isDetected) {
       expansion = 0.5 + (handFactor * 2.0);
    } else {
       expansion = 1.0 + Math.sin(state.clock.elapsedTime) * 0.1;
    }

    // 2. ROTATION (Hand Steering)
    // Smoothly interpolate rotation
    if (isDetected) {
      // handRotation is -1 to 1. Map to rotation speed or absolute angle.
      // Let's use it as added rotation speed for interactivity
      pointsRef.current.rotation.y += handRotation * 0.05;
      
      // Also tilt Z slightly based on rotation for "banking" effect
      pointsRef.current.rotation.z = THREE.MathUtils.lerp(pointsRef.current.rotation.z, -handRotation * 0.5, 0.1);
    } else {
      pointsRef.current.rotation.y += 0.002; // Idle auto-rotate
      pointsRef.current.rotation.z = THREE.MathUtils.lerp(pointsRef.current.rotation.z, 0, 0.1);
    }

    const speed = 0.08;

    for (let i = 0; i < COUNT; i++) {
      const i3 = i * 3;
      
      const tx = targetPositions[i3];
      const ty = targetPositions[i3 + 1];
      const tz = targetPositions[i3 + 2];

      const tcR = targetColors[i3];
      const tcG = targetColors[i3+1];
      const tcB = targetColors[i3+2];

      // PINCH EFFECT: Individual Particle "Selection" / Vibration
      // If pinchStrength is high, add random noise to position
      let noiseX = 0, noiseY = 0, noiseZ = 0;
      if (pinchStrength > 0.1) {
         // High frequency shake
         noiseX = (Math.random() - 0.5) * pinchStrength * 0.5;
         noiseY = (Math.random() - 0.5) * pinchStrength * 0.5;
         noiseZ = (Math.random() - 0.5) * pinchStrength * 0.5;
      }

      // Target position with expansion
      const targetX = tx * expansion + noiseX;
      const targetY = ty * expansion + noiseY;
      const targetZ = tz * expansion + noiseZ;
      
      // Lerp Position
      positions[i3] += (targetX - positions[i3]) * speed;
      positions[i3 + 1] += (targetY - positions[i3 + 1]) * speed;
      positions[i3 + 2] += (targetZ - positions[i3 + 2]) * speed;

      // Lerp Color
      colors[i3] += (tcR - colors[i3]) * 0.05;
      colors[i3+1] += (tcG - colors[i3+1]) * 0.05;
      colors[i3+2] += (tcB - colors[i3+2]) * 0.05;

      // Special Physics for Fireworks
      if (shape === ShapeType.FIREWORKS) {
          positions[i3 + 1] -= 0.01; 
      }
    }

    posAttr.needsUpdate = true;
    colAttr.needsUpdate = true;
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={COUNT}
          array={currentPositions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-color"
          count={COUNT}
          array={currentColors}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.12}
        vertexColors
        transparent
        opacity={0.9}
        sizeAttenuation
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
};

export const ParticleScene: React.FC<SceneProps> = (props) => {
  return (
    <Canvas camera={{ position: [0, 0, 12], fov: 60 }}>
      <color attach="background" args={['#020202']} />
      <ambientLight intensity={0.5} />
      <Particles {...props} />
      <OrbitControls enableZoom={false} enablePan={false} />
      <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
      {props.shape === ShapeType.EPIC_TREE && (
         <Sparkles count={50} scale={10} size={4} speed={0.4} opacity={0.5} color="#fff" />
      )}
    </Canvas>
  );
};