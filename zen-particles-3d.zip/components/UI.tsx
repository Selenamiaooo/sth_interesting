import React from 'react';
import { ShapeType } from '../types';
import { Hand, Maximize, Heart, Flower, Circle, User, Sun, TreePine } from 'lucide-react';

interface UIProps {
  currentShape: ShapeType;
  setShape: (s: ShapeType) => void;
  currentColor: string;
  setColor: (c: string) => void;
  handDistance: number;
  isHandDetected: boolean;
}

const SHAPE_ICONS: Record<ShapeType, React.ReactNode> = {
  [ShapeType.EPIC_TREE]: <TreePine size={18} className="text-green-400" />,
  [ShapeType.HEART]: <Heart size={18} />,
  [ShapeType.FLOWER]: <Flower size={18} />,
  [ShapeType.SATURN]: <Circle size={18} />,
  [ShapeType.BUDDHA]: <User size={18} />,
  [ShapeType.FIREWORKS]: <Sun size={18} />,
  [ShapeType.SPHERE]: <Circle size={18} />,
};

export const UI: React.FC<UIProps> = ({ 
  currentShape, setShape, currentColor, setColor, handDistance, isHandDetected 
}) => {
  
  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      }
    }
  };

  return (
    <>
      {/* Title & Instructions */}
      <div className="absolute top-6 left-6 z-10 pointer-events-none select-none">
        <h1 className="text-3xl font-light text-white tracking-widest mb-2 drop-shadow-lg">
          {currentShape === ShapeType.EPIC_TREE ? "EPIC RADIANCE" : "ZEN PARTICLES"}
        </h1>
        <div className="text-white/50 text-xs md:text-sm max-w-sm leading-relaxed space-y-1">
          <p>✋ <span className="text-blue-400 font-bold">Two Hands</span>: Spread to Zoom / Rotate to Spin</p>
          <p>👌 <span className="text-blue-400 font-bold">Pinch</span>: Agitate/Select Particles</p>
          <p className="opacity-70 text-[10px] mt-2">
            Epic Tree: Monsters → Mario → Dragon → Magic → Moon
          </p>
        </div>
        
        {/* Hand Status Indicator */}
        <div className={`mt-4 flex items-center gap-2 transition-colors duration-500 ${isHandDetected ? 'text-green-400' : 'text-red-400'}`}>
          <Hand size={16} />
          <span className="text-xs uppercase tracking-wider font-bold">
            {isHandDetected ? "Hands Connected" : "No Hands Detected"}
          </span>
        </div>
        
        {isHandDetected && (
          <div className="mt-2 w-32 h-1 bg-white/10 rounded-full overflow-hidden">
            <div 
              className="h-full bg-blue-500 transition-all duration-100 ease-out" 
              style={{ width: `${handDistance * 100}%` }}
            />
          </div>
        )}
      </div>

      {/* Control Panel */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10 
                      bg-black/60 backdrop-blur-xl border border-white/10 rounded-2xl p-4 
                      shadow-2xl flex flex-col md:flex-row items-center gap-6 w-[95%] md:w-auto max-w-4xl">
        
        {/* Shape Selectors */}
        <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto pb-2 md:pb-0 scrollbar-hide">
          {Object.values(ShapeType).map((shape) => (
            <button
              key={shape}
              onClick={() => setShape(shape)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300 whitespace-nowrap
                ${currentShape === shape 
                  ? 'bg-white/20 text-white shadow-lg scale-105 border border-white/20' 
                  : 'text-white/60 hover:text-white hover:bg-white/5'}`}
            >
              {SHAPE_ICONS[shape]}
              <span>{shape}</span>
            </button>
          ))}
        </div>

        <div className="w-px h-8 bg-white/10 hidden md:block"></div>

        {/* Color & Settings */}
        <div className="flex items-center gap-4">
          <div className="relative group">
             <div className="flex items-center gap-2 px-3 py-2 bg-white/5 rounded-lg border border-white/5 hover:border-white/20 transition-all cursor-pointer">
                <div 
                  className="w-4 h-4 rounded-full shadow-inner border border-white/20" 
                  style={{ backgroundColor: currentColor }}
                ></div>
                <span className="text-white/80 text-sm">Tint</span>
             </div>
             <input 
                type="color" 
                value={currentColor}
                onChange={(e) => setColor(e.target.value)}
                className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
             />
          </div>

          <button 
            onClick={toggleFullscreen}
            className="p-2 text-white/60 hover:text-white bg-white/5 rounded-lg hover:bg-white/10 transition-colors"
            title="Toggle Fullscreen"
          >
            <Maximize size={20} />
          </button>
        </div>
      </div>
    </>
  );
};