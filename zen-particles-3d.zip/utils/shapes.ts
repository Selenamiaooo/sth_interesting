import * as THREE from 'three';
import { ShapeType } from '../types';

export const COUNT = 12000; // Increased count for better tree density
const RADIUS = 4;

// Helper to get random point on sphere
const randomSpherePoint = (r: number) => {
  const u = Math.random();
  const v = Math.random();
  const theta = 2 * Math.PI * u;
  const phi = Math.acos(2 * v - 1);
  const x = r * Math.sin(phi) * Math.cos(theta);
  const y = r * Math.sin(phi) * Math.sin(theta);
  const z = r * Math.cos(phi);
  return new THREE.Vector3(x, y, z);
};

export const generateParticles = (type: ShapeType, baseColorHex: string): { positions: Float32Array, colors: Float32Array } => {
  const positions = new Float32Array(COUNT * 3);
  const colors = new Float32Array(COUNT * 3);
  const vec = new THREE.Vector3();
  const color = new THREE.Color();
  const baseColor = new THREE.Color(baseColorHex);

  for (let i = 0; i < COUNT; i++) {
    const i3 = i * 3;
    let r = 0, g = 0, b = 0;

    switch (type) {
      case ShapeType.EPIC_TREE: {
        // Epic Universe Christmas Tree
        // Structure: Cone
        const height = 9;
        const yPos = (Math.random() * height) - (height / 2); // -4.5 to 4.5
        const normalizedY = (yPos + (height / 2)) / height; // 0 (bottom) to 1 (top)
        
        // Radius gets smaller as we go up
        const coneRadius = 3.5 * (1 - normalizedY);
        
        // Spiral distribution
        const angle = i * 0.1 + (normalizedY * 20);
        const rDist = Math.random() * coneRadius;
        
        let x = rDist * Math.cos(angle);
        let z = rDist * Math.sin(angle);
        let y = yPos;

        // THEME LOGIC
        if (normalizedY > 0.96) {
           // MOON (Top)
           const moonR = 0.6 * Math.random();
           const moonTheta = Math.random() * Math.PI * 2;
           const moonPhi = Math.acos(2 * Math.random() - 1);
           x = moonR * Math.sin(moonPhi) * Math.cos(moonTheta);
           y = (height/2) + moonR * Math.sin(moonPhi) * Math.sin(moonTheta);
           z = moonR * Math.cos(moonPhi);
           
           color.setHex(0xffffdd); // Pale Moon Yellow
        } 
        else if (normalizedY > 0.72) {
           // HARRY POTTER (Ministry/Magic) - Gold/Purple/Mystic
           color.setHex(Math.random() > 0.5 ? 0x7f00ff : 0xffd700); 
           // Add some magic swirl
           x *= 1.1; z *= 1.1;
        }
        else if (normalizedY > 0.48) {
           // HOW TO TRAIN YOUR DRAGON (Isle of Berk) - Fire Orange/Viking Wood/Green
           const cRand = Math.random();
           if(cRand > 0.6) color.setHex(0xff4500); // Fire
           else if (cRand > 0.3) color.setHex(0x228b22); // Nature
           else color.setHex(0x8b4513); // Wood/Earth
        }
        else if (normalizedY > 0.24) {
           // SUPER NINTENDO WORLD - Red/Blue/Yellow (Primary)
           const cRand = Math.random();
           if(cRand > 0.66) color.setHex(0xff0000); // Mario Red
           else if (cRand > 0.33) color.setHex(0x0000ff); // Toad Blue
           else color.setHex(0xffff00); // Coin Yellow
        }
        else {
           // DARK UNIVERSE (Monsters) - Dark Green/Grey/Black/Fog
           const cRand = Math.random();
           if(cRand > 0.5) color.setHex(0x2f4f4f); // Dark Slate Gray
           else color.setHex(0x006400); // Dark Green
           
           // Make base wider/messier
           x *= 1.2; z *= 1.2;
        }

        vec.set(x, y, z);
        break;
      }

      case ShapeType.HEART: {
        const t = Math.random() * Math.PI * 2;
        const x = 16 * Math.pow(Math.sin(t), 3);
        const y = 13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t);
        const z = (Math.random() - 0.5) * 4; 
        vec.set(x, y, z).multiplyScalar(0.15);
        color.copy(baseColor);
        break;
      }

      case ShapeType.FLOWER: {
        const angle = i * 137.5 * (Math.PI / 180);
        const r = 0.1 * Math.sqrt(i);
        const x = r * Math.cos(angle);
        const y = (Math.random() - 0.5) * 2;
        const z = r * Math.sin(angle);
        const warp = Math.sin(r * 2) * 2;
        vec.set(x, y + warp, z).multiplyScalar(1.2);
        
        // Gradient color for flower
        color.copy(baseColor).lerp(new THREE.Color('#ffffff'), i / COUNT);
        break;
      }

      case ShapeType.SATURN: {
        const isRing = Math.random() > 0.4;
        if (isRing) {
          const angle = Math.random() * Math.PI * 2;
          const dist = 3 + Math.random() * 2.5;
          vec.set(Math.cos(angle) * dist, (Math.random() - 0.5) * 0.2, Math.sin(angle) * dist);
          color.setHex(0xcdba96); // Ring color
        } else {
          vec.copy(randomSpherePoint(2));
          color.copy(baseColor);
        }
        break;
      }

      case ShapeType.BUDDHA: {
         // Simple stack for abstract figure
        const part = Math.random();
        if (part < 0.25) { // Head
          vec.copy(randomSpherePoint(0.8));
          vec.y += 1.8;
        } else if (part < 0.65) { // Body
          const theta = Math.random() * Math.PI * 2;
          const phi = Math.random() * Math.PI;
          vec.set(1.2 * Math.sin(phi) * Math.cos(theta), 1.5 * Math.sin(phi) * Math.sin(theta), 1.0 * Math.cos(phi));
        } else { // Legs
           const angle = Math.random() * Math.PI * 2;
           const r = 1.0 + Math.random() * 1.5;
           vec.set(r * Math.cos(angle), -1.5 + (Math.random() - 0.5) * 0.8, r * Math.sin(angle) * 0.8);
        }
        color.setHex(0xffd700); // Gold
        break;
      }

      case ShapeType.FIREWORKS: {
        const p = randomSpherePoint(RADIUS * (0.2 + Math.random() * 1.5));
        vec.copy(p).multiplyScalar(Math.random()); 
        color.setHSL(Math.random(), 1, 0.5);
        break;
      }

      case ShapeType.SPHERE:
      default: {
        vec.copy(randomSpherePoint(RADIUS));
        color.copy(baseColor);
        break;
      }
    }

    positions[i3] = vec.x;
    positions[i3 + 1] = vec.y;
    positions[i3 + 2] = vec.z;

    colors[i3] = color.r;
    colors[i3 + 1] = color.g;
    colors[i3 + 2] = color.b;
  }

  return { positions, colors };
};