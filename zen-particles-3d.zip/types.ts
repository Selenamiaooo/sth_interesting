export enum ShapeType {
  EPIC_TREE = 'Epic Tree',
  HEART = 'Heart',
  FLOWER = 'Flower',
  SATURN = 'Saturn',
  BUDDHA = 'Buddha',
  FIREWORKS = 'Fireworks',
  SPHERE = 'Sphere'
}

export interface AppState {
  currentShape: ShapeType;
  particleColor: string;
  handDistance: number; // 0 to 1 normalized (Scale)
  handRotation: number; // -1 to 1 (Steering)
  pinchStrength: number; // 0 to 1 (Particle agitation)
  isHandDetected: boolean;
  pointCount: number;
}