import React, { useState, useCallback } from 'react';
import { ParticleScene } from './components/ParticleScene';
import { UI } from './components/UI';
import { HandManager } from './components/HandManager';
import { ShapeType } from './types';

const App: React.FC = () => {
  const [currentShape, setShape] = useState<ShapeType>(ShapeType.EPIC_TREE);
  const [particleColor, setParticleColor] = useState<string>('#ffffff');
  const [handDistance, setHandDistance] = useState<number>(0.5); // Spread
  const [handRotation, setHandRotation] = useState<number>(0);   // Rotation
  const [pinchStrength, setPinchStrength] = useState<number>(0); // Pinch
  const [isHandDetected, setIsHandDetected] = useState<boolean>(false);

  const handleHandUpdate = useCallback((distance: number, rotation: number, pinch: number, detected: boolean) => {
    setHandDistance(distance);
    setHandRotation(rotation);
    setPinchStrength(pinch);
    setIsHandDetected(detected);
  }, []);

  return (
    <div className="w-full h-screen bg-black relative overflow-hidden">
      
      {/* 3D Scene */}
      <div className="absolute inset-0 z-0">
        <ParticleScene 
          shape={currentShape} 
          color={particleColor} 
          handFactor={handDistance}
          handRotation={handRotation}
          pinchStrength={pinchStrength}
          isDetected={isHandDetected}
        />
      </div>

      {/* Hand Tracking Logic (Invisible/Preview only) */}
      <HandManager onUpdate={handleHandUpdate} />

      {/* Overlay UI */}
      <UI 
        currentShape={currentShape}
        setShape={setShape}
        currentColor={particleColor}
        setColor={setParticleColor}
        handDistance={handDistance}
        isHandDetected={isHandDetected}
      />
    </div>
  );
};

export default App;